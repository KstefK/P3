//
//  Weapon.swift
//  P3_Donald's nephews battle
//
//  Created by Stéphane KERHOAS on 17/11/2021.
//

import Foundation

class Weapon {                          // Weapons
    
    var name: String
    var damage: Int
    
    init(name: String, damage: Int) {
        
        self.name = name
        self.damage = damage
        
    }
}




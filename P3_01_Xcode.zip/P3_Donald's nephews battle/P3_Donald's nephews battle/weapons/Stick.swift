//
//  Stick.swift
//  P3_Donald's nephews battle
//
//  Created by Stéphane KERHOAS on 17/11/2021.
//

import Foundation

class Stick: Weapon {        // Baton
    
    init() {                //Constructor from super class Weapon
        
        super.init(name: "stick" ,damage: 5)
    }
}


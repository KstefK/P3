//
//  SlingShot.swift
//  P3_Donald's nephews battle
//
//  Created by Stéphane KERHOAS on 17/11/2021.
//

import Foundation

class SlingShot: Weapon {     //Lance pierre
    
    init() {                //Constructor from super class Weapon
        
        super.init(name: "slingShot",damage: 10)
    }
}
